from collections import namedtuple

from flask import Flask, render_template, redirect, url_for, request


app = Flask(__name__)

Message = namedtuple('Message', 'text tag')
messages = []


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


@app.route('/nach1', methods=['GET'])
def nach1(): #1
    return render_template('nach1.html', messages = messages)


@app.route('/main', methods=['GET'])
def main(): #1
    return render_template('main.html', messages = messages)


@app.route('/V2', methods=['GET'])
def V2(): #2
    return render_template('V2.html', messages = messages)

@app.route('/t', methods=['GET'])
def t(): #3
    return render_template('t.html', messages = messages)

@app.route('/m', methods=['GET'])
def m(): #4
    return render_template('m.html', messages = messages)

@app.route('/i', methods=['GET'])
def i(): #5
    return render_template('i.html', messages = messages)


@app.route('/k', methods=['GET'])
def k(): #6
    return render_template('k.html', messages = messages)

@app.route('/h', methods=['GET'])
def h(): #7
    return render_template('h.html', messages = messages)

@app.route('/g', methods=['GET'])
def g(): #8
    return render_template('g.html', messages = messages)

@app.route('/n', methods=['GET'])
def n(): #9
    return render_template('n.html', messages = messages)

@app.route('/o', methods=['GET'])
def o(): #10
    return render_template('o.html', messages = messages)

@app.route('/d', methods=['GET'])
def d(): #11
    return render_template('d.html', messages = messages)

@app.route('/j', methods=['GET'])
def j(): #12
    return render_template('j.html', messages = messages)

@app.route('/b', methods=['GET'])
def b(): #13
    return render_template('b.html', messages = messages)

@app.route('/a', methods=['GET'])
def a(): #14
    return render_template('a.html', messages = messages)

@app.route('/w', methods=['GET'])
def w(): #15
    return render_template('w.html', messages = messages)

@app.route('/fa', methods=['GET'])
def fa(): #16
    return render_template('fa.html', messages = messages)

@app.route('/aa', methods=['GET'])
def aa(): #17
    return render_template('aa.html', messages = messages)

@app.route('/bb', methods=['GET'])
def bb(): #18
    return render_template('bb.html', messages = messages)

@app.route('/dd', methods=['GET'])
def dd(): #19
    return render_template('dd.html', messages = messages)


@app.route('/gg', methods=['GET'])
def gg(): #20
    return render_template('gg.html', messages = messages)

@app.route('/ta', methods=['GET'])
def ta(): #21
    return render_template('ta.html', messages = messages)

@app.route('/va', methods=['GET'])
def va(): #22
    return render_template('va.html', messages = messages)

@app.route('/ga', methods=['GET'])
def ga(): #23
    return render_template('ga.html', messages = messages)

@app.route('/ma', methods=['GET'])
def ma(): #24
    return render_template('ma.html', messages = messages)

@app.route('/vse', methods=['GET'])
def vse():
    return render_template('vse.html')


@app.route('/nach2', methods=['GET'])
def nach2():
    return render_template('nach2.html')


@app.route('/t2v1', methods=['GET'])
def t2v1():
    return render_template('t2v1.html')


@app.route('/t2v2', methods=['GET'])
def t2v2():
    return render_template('t2v2.html')


@app.route('/t2v3', methods=['GET'])
def t2v3():
    return render_template('t2v3.html')


@app.route('/t2v4', methods=['GET'])
def t2v4():
    return render_template('t2v4.html')


@app.route('/t2v5', methods=['GET'])
def t2v5():
    return render_template('t2v5.html')


@app.route('/t2itog', methods=['GET'])
def t2itog():
    return render_template('t2itog.html')

@app.route('/add_message', methods=['POST'])

@app.route('/nach3', methods=['GET'])
def nach3():
    return render_template('nach3.html')

@app.route('/t3', methods=['GET'])
def t3():
    return render_template('t3.html')

@app.route('/t3itog', methods=['GET'])
def t3itog():
    return render_template('t3itog.html')

@app.route('/nach4', methods=['GET'])
def nach4():
    return render_template('nach4.html')

@app.route('/t4', methods=['GET'])
def t4():
    return render_template('t4.html')

@app.route('/t4itog', methods=['GET'])
def t4itog():
    return render_template('t4itog.html')

@app.route('/nach5', methods=['GET'])
def nach5():
    return render_template('nach5.html')

@app.route('/t5', methods=['GET'])
def t5():
    return render_template('t5.html')

@app.route('/t5v2', methods=['GET'])
def t5v2():
    return render_template('t5v2.html')

@app.route('/t5v3', methods=['GET'])
def t5v3():
    return render_template('t5v3.html')

@app.route('/t5v4', methods=['GET'])
def t5v4():
    return render_template('t5v4.html')

@app.route('/t5v5', methods=['GET'])
def t5v5():
    return render_template('t5v5.html')

@app.route('/t5v6', methods=['GET'])
def t5v6():
    return render_template('t5v6.html')

@app.route('/t5v7', methods=['GET'])
def t5v7():
    return render_template('t5v7.html')

@app.route('/t5v8', methods=['GET'])
def t5v8():
    return render_template('t5v8.html')

@app.route('/t5v9', methods=['GET'])
def t5v9():
    return render_template('t5v9.html')

@app.route('/t5v10', methods=['GET'])
def t5v10():
    return render_template('t5v10.html')

@app.route('/t5v11', methods=['GET'])
def t5v11():
    return render_template('t5v11.html')

@app.route('/t5v12', methods=['GET'])
def t5v12():
    return render_template('t5v12.html')

@app.route('/t5v13', methods=['GET'])
def t5v13():
    return render_template('t5v13.html')

@app.route('/t5v14', methods=['GET'])
def t5v14():
    return render_template('t5v14.html')

@app.route('/t5v15', methods=['GET'])
def t5v15():
    return render_template('t5v15.html')

@app.route('/t5v16', methods=['GET'])
def t5v16():
    return render_template('t5v16.html')

@app.route('/t5v17', methods=['GET'])
def t5v17():
    return render_template('t5v17.html')

@app.route('/t5v18', methods=['GET'])
def t5v18():
    return render_template('t5v18.html')

@app.route('/t5v19', methods=['GET'])
def t5v19():
    return render_template('t5v19.html')

@app.route('/t5v20', methods=['GET'])
def t5v20():
    return render_template('t5v20.html')

@app.route('/t5itog', methods=['GET'])
def t5itog():
    return render_template('t5itog.html')

@app.route('/VakanRost', methods=['GET'])
def VakanRost():
    return render_template('VakanRost.html')

@app.route('/VakanMosk', methods=['GET'])
def VakanMosk():
    return render_template('VakanMosk.html')

@app.route('/VakanLeningrad', methods=['GET'])
def VakanLeningrad():
    return render_template('VakanLeningrad.html')

@app.route('/VuziLeningrad', methods=['GET'])
def VuziLeningrad():
    return render_template('VuziLeningrad.html')

@app.route('/VuziMosk', methods=['GET'])
def VuziMosk():
    return render_template('VuziMosk.html')

@app.route('/VuziRost', methods=['GET'])
def VuziRost():
    return render_template('VuziRost.html')


def add_message():
    text = request.form['text']
    tag = ''

    messages.append(Message(text, tag))

    return redirect(url_for('main'))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')